from datetime import datetime
from flask import session, Flask, render_template, request, redirect, flash, send_from_directory, url_for, make_response
from sqlalchemy import text, or_
from werkzeug.utils import secure_filename
from models import db, Student, Internship, Admin, Application, Company, WeeklyReport, Coordinator
import os
from flask_mail import Mail, Message

app = Flask(__name__)

basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(basedir, 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

app.secret_key = 'internshipsecretkey'
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'gudinabogale@gmail.com'
app.config['MAIL_PASSWORD'] = 'ehjdfwiwfdsrloff'
app.config['UPLOAD_FOLDER'] = os.path.join(basedir, 'static', 'uploads')
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
ALLOWED_CV_EXTENSIONS = {'pdf', 'doc', 'docx'}
ALLOWED_PHOTO_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif'}
ALLOWED_CERT_EXTENSIONS = {'pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'}
ALLOWED_LOGO_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif'}

mail = Mail(app)

# Initialize SQLAlchemy with the Flask app
db.init_app(app)

def allowed_file(filename, allowed_extensions):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions


def parse_date(date_str):
    if not date_str:
        return None
    try:
        return datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        return None


def send_application_status_email(application, status):
    student = application.student
    internship = application.internship
    if not student or not internship:
        return

    subject = f"Your application for {internship.position} has been {status}"
    if status == 'Accepted':
        body = f"Hello {student.fullname},\n\nCongratulations! Your application for the position of {internship.position} at {internship.company} has been accepted.\n\nPlease wait for further instructions from the company.\n\nBest regards,\nInternship Management Team"
    elif status == 'Rejected':
        body = f"Hello {student.fullname},\n\nThank you for applying for the position of {internship.position} at {internship.company}.\nUnfortunately, your application has not been approved at this time.\n\nWe encourage you to continue applying to other opportunities.\n\nBest regards,\nInternship Management Team"
    elif status == 'Completed':
        certificate_link = url_for('certificate', application_id=application.id, _external=True)
        body = f"Hello {student.fullname},\n\nCongratulations on completing your internship for {internship.position} at {internship.company}.\nYour completion certificate is now available here:\n{certificate_link}\n\nThank you for your hard work!\n\nBest regards,\nInternship Management Team"
    else:
        return

    msg = Message(subject, sender=app.config['MAIL_USERNAME'], recipients=[student.email])
    msg.body = body
    try:
        mail.send(msg)
    except Exception:
        pass


def send_admin_email(application, action):
    student = application.student
    internship = application.internship
    if not student or not internship:
        return

    if action == 'interview':
        subject = f"Interview invitation for {internship.position}"
        body = f"Hello {student.fullname},\n\nYou are invited to an interview for the position of {internship.position} at {internship.company}.\nPlease reply with your availability or wait for the company to contact you with interview details.\n\nBest regards,\nInternship Management Team"
    elif action == 'reminder':
        subject = f"Reminder: your application for {internship.position}"
        body = f"Hello {student.fullname},\n\nThis is a friendly reminder that your application for {internship.position} at {internship.company} is still under review.\nWe will notify you once there is an update.\n\nBest regards,\nInternship Management Team"
    else:
        return

    msg = Message(subject, sender=app.config['MAIL_USERNAME'], recipients=[student.email])
    msg.body = body
    try:
        mail.send(msg)
    except Exception:
        pass

with app.app_context():

    db.create_all()

    with db.engine.connect() as conn:
        existing_student_columns = [row[1] for row in conn.execute(text("PRAGMA table_info(student)"))]
        if 'cv_filename' not in existing_student_columns:
            conn.execute(text("ALTER TABLE student ADD COLUMN cv_filename VARCHAR(200)"))
        if 'profile_photo_filename' not in existing_student_columns:
            conn.execute(text("ALTER TABLE student ADD COLUMN profile_photo_filename VARCHAR(200)"))
        if 'certificate_filename' not in existing_student_columns:
            conn.execute(text("ALTER TABLE student ADD COLUMN certificate_filename VARCHAR(200)"))
        if 'phone' not in existing_student_columns:
            conn.execute(text("ALTER TABLE student ADD COLUMN phone VARCHAR(50)"))
        if 'gpa' not in existing_student_columns:
            conn.execute(text("ALTER TABLE student ADD COLUMN gpa VARCHAR(20)"))
        if 'skills' not in existing_student_columns:
            conn.execute(text("ALTER TABLE student ADD COLUMN skills TEXT"))
        if 'profile_photo_filename' not in existing_student_columns:
            conn.execute(text("ALTER TABLE student ADD COLUMN profile_photo_filename VARCHAR(200)"))
        if 'certificate_filename' not in existing_student_columns:
            conn.execute(text("ALTER TABLE student ADD COLUMN certificate_filename VARCHAR(200)"))

        existing_company_columns = [row[1] for row in conn.execute(text("PRAGMA table_info(company)"))]
        if 'description' not in existing_company_columns:
            conn.execute(text("ALTER TABLE company ADD COLUMN description TEXT"))
        if 'logo_filename' not in existing_company_columns:
            conn.execute(text("ALTER TABLE company ADD COLUMN logo_filename VARCHAR(200)"))

        existing_internship_columns = [row[1] for row in conn.execute(text("PRAGMA table_info(internship)"))]
        if 'company_id' not in existing_internship_columns:
            conn.execute(text("ALTER TABLE internship ADD COLUMN company_id INTEGER"))
        if 'start_date' not in existing_internship_columns:
            conn.execute(text("ALTER TABLE internship ADD COLUMN start_date DATE"))
        if 'end_date' not in existing_internship_columns:
            conn.execute(text("ALTER TABLE internship ADD COLUMN end_date DATE"))

    if not Admin.query.filter_by(
        username='admin'
    ).first():

        admin = Admin(
            username='admin',
            password='admin123'
        )

        db.session.add(admin)

    if not Coordinator.query.filter_by(
        email='coordinator@example.com'
    ).first():

        coordinator = Coordinator(
            fullname='Coordinator User',
            email='coordinator@example.com',
            department='Supervision',
            password='coord123'
        )

        db.session.add(coordinator)

    db.session.commit()

@app.route('/')
def home():

    total_students = Student.query.count()
    total_internships = Internship.query.count()
    recent_internships = Internship.query.order_by(
        Internship.id.desc()
    ).limit(3).all()

    return render_template(
        'index.html',
        total_students=total_students,
        total_internships=total_internships,
        recent_internships=recent_internships
    )

@app.route('/register', methods=['GET', 'POST'])
def register():

    if request.method == 'POST':

        fullname = request.form['fullname']
        email = request.form['email']
        department = request.form['department']
        password = request.form['password']
        phone = request.form.get('phone')
        gpa = request.form.get('gpa')
        skills = request.form.get('skills')
        cv_file = request.files.get('cv')
        profile_photo_file = request.files.get('profile_photo')
        certificate_file = request.files.get('certificate')

        cv_filename = None
        profile_photo_filename = None
        certificate_filename = None

        if Student.query.filter_by(email=email).first():
            flash('A student with that email already exists.')
            return render_template('register.html')

        if cv_file and cv_file.filename:
            if allowed_file(cv_file.filename, ALLOWED_CV_EXTENSIONS):
                filename = secure_filename(cv_file.filename)
                cv_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                cv_file.save(cv_path)
                cv_filename = filename
            else:
                flash('Unsupported CV format. Please upload PDF, DOC, or DOCX.')
                return render_template('register.html')

        if profile_photo_file and profile_photo_file.filename:
            if allowed_file(profile_photo_file.filename, ALLOWED_PHOTO_EXTENSIONS):
                filename = secure_filename(profile_photo_file.filename)
                photo_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                profile_photo_file.save(photo_path)
                profile_photo_filename = filename
            else:
                flash('Unsupported profile photo format. Please upload JPG, JPEG, PNG, or GIF.')
                return render_template('register.html')

        if certificate_file and certificate_file.filename:
            if allowed_file(certificate_file.filename, ALLOWED_CERT_EXTENSIONS):
                filename = secure_filename(certificate_file.filename)
                certificate_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                certificate_file.save(certificate_path)
                certificate_filename = filename
            else:
                flash('Unsupported certificate format. Please upload PDF, DOC, DOCX, JPG, JPEG, or PNG.')
                return render_template('register.html')

        student = Student(
            fullname=fullname,
            email=email,
            department=department,
            password=password,
            phone=phone,
            gpa=gpa,
            skills=skills,
            cv_filename=cv_filename,
            profile_photo_filename=profile_photo_filename,
            certificate_filename=certificate_filename
        )

        db.session.add(student)
        db.session.commit()

        msg = Message(
            'Welcome to Internship Management System',
            sender=app.config['MAIL_USERNAME'],
            recipients=[email]
        )

        msg.body = f"""
Hello {fullname},

Welcome to the Internship Management System.

Your registration was successful.
"""

        mail.send(msg)
        flash('Registration successful! Please login.')

        return redirect('/student_login')

    return render_template('register.html')

@app.route('/company_register', methods=['GET', 'POST'])
def company_register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        location = request.form['location']
        password = request.form['password']
        description = request.form.get('description')
        logo_file = request.files.get('logo')
        logo_filename = None

        if Company.query.filter_by(email=email).first():
            flash('A company with that email already exists.')
            return render_template('company_register.html')

        if logo_file and logo_file.filename:
            if allowed_file(logo_file.filename, ALLOWED_LOGO_EXTENSIONS):
                filename = secure_filename(logo_file.filename)
                logo_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                logo_file.save(logo_path)
                logo_filename = filename
            else:
                flash('Unsupported logo format. Please upload JPG, JPEG, PNG, or GIF.')
                return render_template('company_register.html')

        company = Company(
            name=name,
            email=email,
            location=location,
            password=password,
            description=description,
            logo_filename=logo_filename
        )

        db.session.add(company)
        db.session.commit()
        flash('Company registered successfully! Please login.')
        return redirect('/company_login')

    return render_template('company_register.html')


@app.route('/company_profile', methods=['GET', 'POST'])
def company_profile():
    if 'company_id' not in session:
        return redirect('/company_login')

    company = Company.query.get(session['company_id'])
    if request.method == 'POST':
        company.name = request.form['name']
        company.location = request.form['location']
        company.description = request.form.get('description')
        password = request.form.get('password')
        if password:
            company.password = password

        logo_file = request.files.get('logo')
        if logo_file and logo_file.filename:
            if allowed_file(logo_file.filename, ALLOWED_LOGO_EXTENSIONS):
                filename = secure_filename(logo_file.filename)
                logo_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                logo_file.save(logo_path)
                company.logo_filename = filename
            else:
                flash('Unsupported logo format. Please upload JPG, JPEG, PNG, or GIF.')
                return render_template('company_profile.html', company=company)

        db.session.commit()
        flash('Company profile updated successfully.')
        return redirect('/company_profile')

    return render_template('company_profile.html', company=company)

@app.route('/login', methods=['GET', 'POST'])
def login_choice():
    selected_role = 'student'
    identifier = ''

    if request.method == 'POST':
        role = request.form.get('role', 'student')
        selected_role = role if role in ['student', 'admin', 'company', 'coordinator'] else 'student'
        identifier = request.form.get('identifier', '').strip()
        password = request.form.get('password', '')

        if selected_role == 'admin':
            admin = Admin.query.filter_by(
                username=identifier,
                password=password
            ).first()
            if admin:
                session['admin_id'] = admin.id
                return redirect('/admin_dashboard')
            flash('Invalid admin credentials')

        elif selected_role == 'company':
            company = Company.query.filter_by(
                email=identifier,
                password=password
            ).first()
            if company:
                session['company_id'] = company.id
                return redirect('/company_dashboard')
            flash('Invalid company credentials')

        elif selected_role == 'coordinator':
            coordinator = Coordinator.query.filter_by(
                email=identifier,
                password=password
            ).first()
            if coordinator:
                session['coordinator_id'] = coordinator.id
                return redirect('/coordinator_dashboard')
            flash('Invalid coordinator credentials')

        else:
            student = Student.query.filter_by(
                email=identifier,
                password=password
            ).first()
            if student:
                session['student_id'] = student.id
                return redirect('/student_dashboard')
            flash('Invalid login credentials')

    return render_template(
        'login_choice.html',
        selected_role=selected_role,
        identifier=identifier
    )

@app.route('/student_login', methods=['GET', 'POST'])
def student_login():

    if request.method == 'POST':

        email = request.form['email']

        password = request.form['password']

        student = Student.query.filter_by(
            email=email,
            password=password
        ).first()

        if student:

            session['student_id'] = student.id

            return redirect('/student_dashboard')

        flash('Invalid login credentials')

    return render_template('login.html')

@app.route('/company_login', methods=['GET', 'POST'])
def company_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        company = Company.query.filter_by(
            email=email,
            password=password
        ).first()

        if company:
            session['company_id'] = company.id
            return redirect('/company_dashboard')

        flash('Invalid company credentials')

    return render_template('company_login.html')

@app.route('/coordinator_register', methods=['GET', 'POST'])
def coordinator_register():
    if request.method == 'POST':
        fullname = request.form['fullname']
        email = request.form['email']
        department = request.form.get('department')
        phone = request.form.get('phone')
        password = request.form['password']

        if Coordinator.query.filter_by(email=email).first():
            flash('A coordinator with that email already exists.')
            return render_template('coordinator_register.html')

        coordinator = Coordinator(
            fullname=fullname,
            email=email,
            department=department,
            phone=phone,
            password=password
        )

        db.session.add(coordinator)
        db.session.commit()
        session['coordinator_id'] = coordinator.id
        return redirect('/coordinator_dashboard')

    return render_template('coordinator_register.html')


@app.route('/coordinator_login', methods=['GET', 'POST'])
def coordinator_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        coordinator = Coordinator.query.filter_by(
            email=email,
            password=password
        ).first()

        if coordinator:
            session['coordinator_id'] = coordinator.id
            return redirect('/coordinator_dashboard')

        flash('Invalid coordinator credentials')

    return render_template('coordinator_login.html')


@app.route('/coordinator_dashboard')
def coordinator_dashboard():
    if 'coordinator_id' not in session:
        return redirect('/coordinator_login')

    coordinator = Coordinator.query.get(session['coordinator_id'])
    total_students = Student.query.count()
    total_internships = Internship.query.count()
    total_applications = Application.query.count()
    accepted_applications = Application.query.filter_by(status='Accepted').count()
    recent_applications = Application.query.order_by(Application.applied_at.desc()).limit(5).all()
    recent_reports = WeeklyReport.query.order_by(WeeklyReport.created_at.desc()).limit(5).all()

    return render_template(
        'coordinator_dashboard.html',
        coordinator=coordinator,
        total_students=total_students,
        total_internships=total_internships,
        total_applications=total_applications,
        accepted_applications=accepted_applications,
        recent_applications=recent_applications,
        recent_reports=recent_reports
    )


@app.route('/dashboard')
def dashboard():

    total_students = Student.query.count()

    total_internships = Internship.query.count()

    recent_students = Student.query.order_by(
        Student.id.desc()
    ).limit(5)

    recent_internships = Internship.query.order_by(
        Internship.id.desc()
    ).limit(5)

    return render_template(
        'dashboard.html',
        total_students=total_students,
        total_internships=total_internships,
        recent_students=recent_students,
        recent_internships=recent_internships
    )


@app.route('/students')
def students():

    search = request.args.get('search')

    if search:

        all_students = Student.query.filter(
            Student.fullname.contains(search)
        ).all()

    else:

        all_students = Student.query.all()

    return render_template(
        'students.html',
        students=all_students
    )

@app.route('/student_dashboard')
def student_dashboard():

    if 'student_id' not in session:

        return redirect('/student_login')

    student = Student.query.get(
        session['student_id']
    )
    report_count = WeeklyReport.query.filter_by(student_id=student.id).count()

    return render_template(
        'student_dashboard.html',
        student=student,
        report_count=report_count
    )

@app.route('/company_dashboard')
def company_dashboard():
    if 'company_id' not in session:
        return redirect('/company_login')

    company = Company.query.get(session['company_id'])
    return render_template('company_dashboard.html', company=company)

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'student_id' not in session:
        return redirect('/student_login')

    student = Student.query.get(session['student_id'])

    if request.method == 'POST':
        student.fullname = request.form['fullname']
        student.email = request.form['email']
        student.department = request.form['department']
        student.phone = request.form.get('phone')
        student.gpa = request.form.get('gpa')
        student.skills = request.form.get('skills')
        password = request.form.get('password')
        if password:
            student.password = password

        cv_file = request.files.get('cv')
        if cv_file and cv_file.filename:
            if allowed_file(cv_file.filename, ALLOWED_CV_EXTENSIONS):
                filename = secure_filename(cv_file.filename)
                cv_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                cv_file.save(cv_path)
                student.cv_filename = filename
            else:
                flash('Unsupported CV format. Please upload PDF, DOC, or DOCX.')
                return render_template('profile.html', student=student)

        profile_photo_file = request.files.get('profile_photo')
        if profile_photo_file and profile_photo_file.filename:
            if allowed_file(profile_photo_file.filename, ALLOWED_PHOTO_EXTENSIONS):
                filename = secure_filename(profile_photo_file.filename)
                photo_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                profile_photo_file.save(photo_path)
                student.profile_photo_filename = filename
            else:
                flash('Unsupported profile photo format. Please upload JPG, JPEG, PNG, or GIF.')
                return render_template('profile.html', student=student)

        certificate_file = request.files.get('certificate')
        if certificate_file and certificate_file.filename:
            if allowed_file(certificate_file.filename, ALLOWED_CERT_EXTENSIONS):
                filename = secure_filename(certificate_file.filename)
                certificate_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                certificate_file.save(certificate_path)
                student.certificate_filename = filename
            else:
                flash('Unsupported certificate format. Please upload PDF, DOC, DOCX, JPG, JPEG, or PNG.')
                return render_template('profile.html', student=student)

        db.session.commit()
        flash('Profile updated successfully.')
        return redirect('/profile')

    return render_template('profile.html', student=student)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/edit_student/<int:id>', methods=['GET', 'POST'])
def edit_student(id):

    if 'admin_id' not in session:
        return redirect('/admin_login')

    student = Student.query.get(id)

    if request.method == 'POST':

        student.fullname = request.form['fullname']
        student.email = request.form['email']
        student.department = request.form['department']
        student.phone = request.form.get('phone')
        student.gpa = request.form.get('gpa')
        student.skills = request.form.get('skills')
        if request.form.get('password'):
            student.password = request.form['password']

        db.session.commit()

        return redirect('/students')

    return render_template(
        'edit_student.html',
        student=student
    )

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():

    if request.method == 'POST':

        username = request.form['username']

        password = request.form['password']

        admin = Admin.query.filter_by(
            username=username,
            password=password
        ).first()

        if admin:

            session['admin_id'] = admin.id

            return redirect('/admin_dashboard')

        flash('Invalid admin credentials')

    return render_template('admin_login.html')

@app.route('/admin_dashboard')
def admin_dashboard():

    if 'admin_id' not in session:

        return redirect('/admin_login')

    students = Student.query.all()
    internships = Internship.query.all()
    applications = Application.query.order_by(Application.applied_at.desc()).all()
    weekly_reports = WeeklyReport.query.order_by(WeeklyReport.created_at.desc()).all()

    total_applications = len(applications)
    accepted_count = Application.query.filter_by(status='Accepted').count()
    approval_rate = round((accepted_count / total_applications * 100), 1) if total_applications else 0

    query = text("SELECT strftime('%Y-%m', applied_at) as month, COUNT(*) as count FROM application GROUP BY month ORDER BY month DESC LIMIT 6")
    monthly_rows = db.session.execute(query).fetchall()
    monthly_applications = [{'month': row[0], 'count': row[1]} for row in monthly_rows]

    return render_template(
        'admin_dashboard.html',
        students=students,
        internships=internships,
        applications=applications,
        weekly_reports=weekly_reports,
        total_applications=total_applications,
        accepted_count=accepted_count,
        approval_rate=approval_rate,
        monthly_applications=monthly_applications
    )

@app.route('/delete_student/<int:id>')
def delete_student(id):
    if 'admin_id' not in session:
        return redirect('/admin_login')

    student = Student.query.get(id)
    db.session.delete(student)
    db.session.commit()
    return redirect('/students')


@app.route('/internships')
def internships():

    search = request.args.get('search', '').strip()
    internships_query = Internship.query

    if search:
        internships_query = internships_query.filter(
            or_(
                Internship.position.contains(search),
                Internship.company.contains(search),
                Internship.location.contains(search),
                Internship.description.contains(search)
            )
        )

    all_internships = internships_query.all()
    applied_ids = []
    if 'student_id' in session:
        applied_ids = [application.internship_id for application in Application.query.filter_by(student_id=session['student_id']).all()]

    return render_template(
        'internships.html',
        internships=all_internships,
        applied_ids=applied_ids,
        search=search
    )

@app.route('/apply/<int:internship_id>', methods=['POST'])
def apply_internship(internship_id):
    if 'student_id' not in session:
        return redirect('/student_login')

    student_id = session['student_id']
    existing = Application.query.filter_by(
        student_id=student_id,
        internship_id=internship_id
    ).first()

    if not existing:
        application = Application(
            student_id=student_id,
            internship_id=internship_id,
            status='Pending'
        )
        db.session.add(application)
        db.session.commit()
        flash('Your application has been submitted and is pending review.')
    else:
        flash('You have already applied for this internship.')

    return redirect('/internships')

@app.route('/my_applications')
def my_applications():
    if 'student_id' not in session:
        return redirect('/student_login')

    applications = Application.query.filter_by(student_id=session['student_id']).all()
    return render_template('my_applications.html', applications=applications)

@app.route('/weekly_report/<int:application_id>', methods=['GET', 'POST'])
def weekly_report(application_id):
    if 'student_id' not in session:
        return redirect('/student_login')

    application = Application.query.get(application_id)
    if not application or application.student_id != session['student_id']:
        return redirect('/student_dashboard')

    if request.method == 'POST':
        week_number = request.form.get('week_number')
        progress = request.form.get('progress')

        if not week_number or not progress:
            flash('Please provide both week number and progress details.')
            return render_template('weekly_report.html', application=application)

        report = WeeklyReport(
            student_id=application.student_id,
            internship_id=application.internship_id,
            application_id=application.id,
            week_number=int(week_number),
            progress=progress
        )
        db.session.add(report)
        db.session.commit()
        flash('Weekly report submitted successfully.')
        return redirect('/weekly_reports')

    return render_template('weekly_report.html', application=application)

@app.route('/weekly_reports')
def weekly_reports():
    if 'student_id' not in session:
        return redirect('/student_login')

    reports = WeeklyReport.query.filter_by(student_id=session['student_id']).order_by(WeeklyReport.created_at.desc()).all()
    return render_template('weekly_reports.html', reports=reports)

@app.route('/update_application_status/<int:application_id>/<status>')
def update_application_status(application_id, status):
    if 'admin_id' not in session:
        return redirect('/admin_login')

    if status not in ['Pending', 'Accepted', 'Rejected', 'Completed']:
        return redirect('/admin_dashboard')

    application = Application.query.get(application_id)
    if application:
        application.status = status
        db.session.commit()
        if status in ['Accepted', 'Rejected', 'Completed']:
            send_application_status_email(application, status)
    return redirect('/admin_dashboard')


@app.route('/certificate/<int:application_id>')
def certificate(application_id):
    if 'student_id' not in session:
        return redirect('/student_login')

    application = Application.query.get(application_id)
    if not application or application.student_id != session['student_id']:
        return redirect('/student_dashboard')

    if application.status != 'Completed':
        flash('Certificate is only available for completed internships.')
        return redirect('/my_applications')

    issued_date = datetime.utcnow().strftime('%Y-%m-%d')
    return render_template('certificate.html', application=application, issued_date=issued_date)


@app.route('/send_application_email/<int:application_id>/<action>')
def send_application_email(application_id, action):
    if 'admin_id' not in session:
        return redirect('/admin_login')

    if action not in ['interview', 'reminder']:
        return redirect('/admin_dashboard')

    application = Application.query.get(application_id)
    if application:
        send_admin_email(application, action)
        flash(f'{action.capitalize()} email sent successfully.')

    return redirect('/admin_dashboard')

@app.route('/add_internship', methods=['GET', 'POST'])
def add_internship():
    if 'admin_id' not in session:
        return redirect('/admin_login')

    if request.method == 'POST':
        company = request.form['company']
        position = request.form['position']
        location = request.form['location']
        salary = request.form['salary']
        description = request.form['description']
        start_date = parse_date(request.form.get('start_date'))
        end_date = parse_date(request.form.get('end_date'))

        new_internship = Internship(
            company=company,
            position=position,
            location=location,
            salary=salary,
            description=description,
            start_date=start_date,
            end_date=end_date
        )

        db.session.add(new_internship)
        db.session.commit()

        return redirect('/admin_dashboard')

    return render_template('add_internship.html', company_mode=False)

@app.route('/company_add_internship', methods=['GET', 'POST'])
def company_add_internship():
    if 'company_id' not in session:
        return redirect('/company_login')

    company = Company.query.get(session['company_id'])

    if request.method == 'POST':
        position = request.form['position']
        location = request.form['location']
        salary = request.form['salary']
        description = request.form['description']
        start_date = parse_date(request.form.get('start_date'))
        end_date = parse_date(request.form.get('end_date'))

        new_internship = Internship(
            company=company.name,
            company_id=company.id,
            position=position,
            location=location,
            salary=salary,
            description=description,
            start_date=start_date,
            end_date=end_date
        )

        db.session.add(new_internship)
        db.session.commit()
        flash('Internship posted successfully.')
        return redirect('/company_dashboard')

    return render_template('add_internship.html', company_mode=True, company_name=company.name)


@app.route('/delete_internship/<int:id>')
def delete_internship(id):
    internship = Internship.query.get(id)

    if 'admin_id' in session:
        pass
    elif 'company_id' in session:
        if internship.company_id != session['company_id']:
            return redirect('/company_dashboard')
    else:
        return redirect('/')

    db.session.delete(internship)
    db.session.commit()

    if 'admin_id' in session:
        return redirect('/admin_dashboard')
    return redirect('/company_dashboard')


@app.route('/logout')
def logout():
    session.pop('student_id', None)
    session.pop('admin_id', None)
    session.pop('company_id', None)
    return redirect('/')


if __name__ == '__main__':
    app.run(debug=True)
