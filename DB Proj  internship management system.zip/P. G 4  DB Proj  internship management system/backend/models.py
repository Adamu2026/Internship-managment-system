from datetime import datetime
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()


class Student(db.Model):
    """Student entity with profile and academic information"""
    
    id = db.Column(db.Integer, primary_key=True)
    coordinator_id = db.Column(db.Integer, db.ForeignKey('coordinator.id'), nullable=True)
    job_number = db.Column(db.String(50), nullable=True)
    student_name = db.Column(db.String(100))
    fullname = db.Column(db.String(100))  # Alias for student_name
    email = db.Column(db.String(100), unique=True)
    phone = db.Column(db.String(50), nullable=True)
    semester = db.Column(db.Integer, nullable=True)
    cgpa = db.Column(db.Numeric(3, 2), nullable=True)
    gpa = db.Column(db.String(20), nullable=True)  # Kept for backward compatibility
    join_date = db.Column(db.Date, nullable=True)
    status = db.Column(db.String(50), default='Active')
    department = db.Column(db.String(100))
    password = db.Column(db.String(100))
    skills = db.Column(db.Text, nullable=True)
    cv_filename = db.Column(db.String(200), nullable=True)
    profile_photo_filename = db.Column(db.String(200), nullable=True)
    certificate_filename = db.Column(db.String(200), nullable=True)
    role = db.Column(db.String(20), default='student')
    
    # Relationship
    coordinator = db.relationship('Coordinator', backref='students')


class Admin(db.Model):
    """Admin entity for system administration"""
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100))
    password = db.Column(db.String(100))


class Company(db.Model):
    """Company entity posting internship opportunities"""
    
    id = db.Column(db.Integer, primary_key=True)
    company_name = db.Column(db.String(100))
    name = db.Column(db.String(100))  # Alias for company_name
    industry = db.Column(db.String(100), nullable=True)
    contact_person = db.Column(db.String(100), nullable=True)
    email = db.Column(db.String(100), unique=True)
    phone = db.Column(db.String(50), nullable=True)
    address = db.Column(db.String(200), nullable=True)
    website = db.Column(db.String(200), nullable=True)
    location = db.Column(db.String(100))
    password = db.Column(db.String(100))
    description = db.Column(db.Text, nullable=True)
    logo_filename = db.Column(db.String(200), nullable=True)


class Coordinator(db.Model):
    """Coordinator entity for supervising students"""
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    fullname = db.Column(db.String(100))  # Alias for name
    email = db.Column(db.String(100), unique=True)
    phone = db.Column(db.String(50), nullable=True)
    department = db.Column(db.String(100), nullable=True)
    password = db.Column(db.String(100))


class Internship(db.Model):
    """Internship opportunities posted by companies"""
    
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'))
    title = db.Column(db.String(100))
    position = db.Column(db.String(100))  # Alias for title
    description = db.Column(db.Text)
    domain = db.Column(db.String(100), nullable=True)
    location = db.Column(db.String(100))
    start_date = db.Column(db.Date, nullable=True)
    end_date = db.Column(db.Date, nullable=True)
    stipend = db.Column(db.Numeric(10, 2), nullable=True)
    salary = db.Column(db.String(100), nullable=True)  # Kept for backward compatibility
    openings = db.Column(db.Integer, default=1)
    posted_date = db.Column(db.Date, default=datetime.utcnow)
    status = db.Column(db.String(50), default='Open')
    company = db.Column(db.String(100), nullable=True)  # Deprecated, use company_id
    
    # Relationships
    company_obj = db.relationship('Company', backref='internships')


class Application(db.Model):
    """Student applications to internships"""
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'))
    internship_id = db.Column(db.Integer, db.ForeignKey('internship.id'))
    application_date = db.Column(db.Date, default=datetime.utcnow)
    applied_at = db.Column(db.DateTime, default=datetime.utcnow)  # Kept for compatibility
    status = db.Column(db.String(50), default='Pending')
    resume_path = db.Column(db.String(200), nullable=True)
    cover_letter = db.Column(db.Text, nullable=True)
    
    # Relationships
    student = db.relationship('Student', backref='applications')
    internship = db.relationship('Internship', backref='applications')


class SupervisorAllocation(db.Model):
    """Allocation of coordinators to students as supervisors"""
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'))
    coordinator_id = db.Column(db.Integer, db.ForeignKey('coordinator.id'))
    assigned_date = db.Column(db.Date, default=datetime.utcnow)
    
    # Relationships
    student = db.relationship('Student', backref='supervisor_allocations')
    coordinator = db.relationship('Coordinator', backref='supervisor_allocations')


class InternshipProgress(db.Model):
    """Track student progress during internship"""
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'))
    internship_id = db.Column(db.Integer, db.ForeignKey('internship.id'))
    report_date = db.Column(db.Date, default=datetime.utcnow)
    work_done = db.Column(db.Text)
    learning = db.Column(db.Text, nullable=True)
    challenges = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(50), default='In Progress')
    
    # Relationships
    student = db.relationship('Student', backref='progress_reports')
    internship = db.relationship('Internship', backref='progress_reports')


class Evaluation(db.Model):
    """Evaluation of student performance by company/coordinator"""
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'))
    internship_id = db.Column(db.Integer, db.ForeignKey('internship.id'))
    evaluator_type = db.Column(db.String(50))  # 'Company' or 'Coordinator'
    evaluator_name = db.Column(db.String(100))
    rating = db.Column(db.Numeric(3, 2))
    feedback = db.Column(db.Text)
    evaluated_date = db.Column(db.Date, default=datetime.utcnow)
    
    # Relationships
    student = db.relationship('Student', backref='evaluations')
    internship = db.relationship('Internship', backref='evaluations')


class OfferLetter(db.Model):
    """Offer letters generated for accepted applications"""
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'))
    internship_id = db.Column(db.Integer, db.ForeignKey('internship.id'))
    offer_date = db.Column(db.Date, default=datetime.utcnow)
    letter_path = db.Column(db.String(200))
    status = db.Column(db.String(50), default='Sent')
    
    # Relationships
    student = db.relationship('Student', backref='offer_letters')
    internship = db.relationship('Internship', backref='offer_letters')


class Certificate(db.Model):
    """Completion certificates for students"""
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'))
    internship_id = db.Column(db.Integer, db.ForeignKey('internship.id'))
    certificate_date = db.Column(db.Date, default=datetime.utcnow)
    certificate_path = db.Column(db.String(200))
    
    # Relationships
    student = db.relationship('Student', backref='certificates')
    internship = db.relationship('Internship', backref='certificates')


class WeeklyReport(db.Model):
    """Weekly progress reports (legacy - consider using InternshipProgress)"""
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'))
    internship_id = db.Column(db.Integer, db.ForeignKey('internship.id'))
    application_id = db.Column(db.Integer, db.ForeignKey('application.id'))
    week_number = db.Column(db.Integer)
    progress = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    student = db.relationship('Student', backref='weekly_reports')
    internship = db.relationship('Internship', backref='weekly_reports')
    application = db.relationship('Application', backref='weekly_reports')