"""
Database Schema Viewer
Shows all tables and their columns
"""

import sqlite3
import os

def view_schema():
    """Display database schema in a readable format"""
    
    db_path = os.path.join('database', 'app.db')
    
    if not os.path.exists(db_path):
        print(f"❌ Database not found at: {db_path}")
        return
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Get all tables
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
    tables = cursor.fetchall()
    
    print("=" * 80)
    print(" DATABASE SCHEMA - Internship Management System")
    print("=" * 80)
    print()
    
    for (table_name,) in tables:
        # Skip SQLite internal tables
        if table_name.startswith('sqlite_'):
            continue
        
        print(f"📋 TABLE: {table_name}")
        print("-" * 80)
        
        # Get column information
        cursor.execute(f"PRAGMA table_info({table_name})")
        columns = cursor.fetchall()
        
        print(f"{'Column Name':<30} {'Type':<20} {'Nullable':<10} {'Default':<15}")
        print("-" * 80)
        
        for col in columns:
            col_id, col_name, col_type, not_null, default_val, pk = col
            nullable = "NOT NULL" if not_null else "NULL"
            default = str(default_val) if default_val else "-"
            pk_marker = " [PK]" if pk else ""
            
            print(f"{col_name:<30} {col_type:<20} {nullable:<10} {default:<15}{pk_marker}")
        
        # Get row count
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        count = cursor.fetchone()[0]
        print(f"\n📊 Row count: {count}")
        print()
    
    # Show foreign key relationships
    print("=" * 80)
    print(" FOREIGN KEY RELATIONSHIPS")
    print("=" * 80)
    print()
    
    for (table_name,) in tables:
        if table_name.startswith('sqlite_'):
            continue
        
        cursor.execute(f"PRAGMA foreign_key_list({table_name})")
        foreign_keys = cursor.fetchall()
        
        if foreign_keys:
            print(f"📌 {table_name}:")
            for fk in foreign_keys:
                fk_id, seq, ref_table, from_col, to_col = fk[:5]
                print(f"   {from_col} → {ref_table}.{to_col}")
            print()
    
    conn.close()
    
    print("=" * 80)
    print(" Database location: " + os.path.abspath(db_path))
    print("=" * 80)

if __name__ == '__main__':
    view_schema()
