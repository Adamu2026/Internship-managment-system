# ER Diagram Explanation

## System Actors

The Student Internship Management System has **4 main actors**:

### 🎓 STUDENT
Students seeking internship opportunities
- Create profile with CV, skills, and academic info
- Browse and apply for internships
- Submit progress reports
- Receive evaluations and certificates

### 🏢 COMPANY
Companies offering internship positions
- Post internship opportunities
- Review student applications
- Evaluate student performance
- Issue offer letters

### 👨‍🏫 COORDINATOR
Academic supervisors monitoring students
- Supervise assigned students
- Review progress reports
- Conduct evaluations
- Monitor internship completion

### 🔧 ADMIN
System administrators
- Manage all users (students, companies, coordinators)
- Oversee applications and internships
- View system analytics and reports
- Configure system settings

## Core Entities and Relationships

### 1. STUDENT Entity
```
┌─────────────────────────┐
│       STUDENT           │
├─────────────────────────┤
│ PK  student_id          │
│ FK  coordinator_id      │
│     job_number          │
│     student_name        │
│     email               │
│     phone               │
│     semester            │
│     cgpa                │
│     join_date           │
│     status              │
│     department          │
│     skills              │
│     cv_filename         │
│     profile_photo       │
│     certificate         │
└─────────────────────────┘
```

**Relationships:**
- Is supervised by ONE Coordinator (N:1)
- Submits MANY Applications (1:N)
- Has MANY Progress Reports (1:N)
- Receives MANY Evaluations (1:N)
- Receives MANY Offer Letters (1:N)
- Earns MANY Certificates (1:N)

### 2. COMPANY Entity
```
┌─────────────────────────┐
│       COMPANY           │
├─────────────────────────┤
│ PK  company_id          │
│     company_name        │
│     industry            │
│     contact_person      │
│     email               │
│     phone               │
│     address             │
│     website             │
│     location            │
│     description         │
│     logo_filename       │
└─────────────────────────┘
```

**Relationships:**
- Posts MANY Internships (1:N)

### 3. INTERNSHIP Entity
```
┌─────────────────────────┐
│      INTERNSHIP         │
├─────────────────────────┤
│ PK  internship_id       │
│ FK  company_id          │
│     title               │
│     description         │
│     domain              │
│     location            │
│     start_date          │
│     end_date            │
│     stipend             │
│     openings            │
│     posted_date         │
│     status              │
└─────────────────────────┘
```

**Relationships:**
- Belongs to ONE Company (N:1)
- Receives MANY Applications (1:N)
- Generates Offer Letters (through Applications)
- Tracked by Progress Reports (1:N)
- Subject of Evaluations (1:N)
- Generates Certificates (upon completion)

### 4. APPLICATION Entity (Junction)
```
┌─────────────────────────┐
│      APPLICATION        │
├─────────────────────────┤
│ PK  application_id      │
│ FK  student_id          │
│ FK  internship_id       │
│     application_date    │
│     status              │
│     resume_path         │
│     cover_letter        │
└─────────────────────────┘
```

**This is a junction table** connecting Students and Internships (Many-to-Many relationship)

**Relationships:**
- Links ONE Student to ONE Internship (N:1, N:1)
- Generates ONE Offer Letter (when accepted) (1:1)

**Status Flow:**
```
Pending → Accepted → Completed
   ↓         ↓          ↓
Rejected  Offer    Certificate
          Letter
```

### 5. COORDINATOR Entity
```
┌─────────────────────────┐
│     COORDINATOR         │
├─────────────────────────┤
│ PK  coordinator_id      │
│     name                │
│     email               │
│     phone               │
│     department          │
└─────────────────────────┘
```

**Relationships:**
- Supervises MANY Students (1:N)
- Has MANY Supervisor Allocations (1:N)

### 6. SUPERVISOR_ALLOCATION Entity
```
┌─────────────────────────┐
│  SUPERVISOR_ALLOCATION  │
├─────────────────────────┤
│ PK  allocation_id       │
│ FK  student_id          │
│ FK  coordinator_id      │
│     assigned_date       │
└─────────────────────────┘
```

**Purpose:** Formally tracks which coordinator supervises which student

### 7. INTERNSHIP_PROGRESS Entity
```
┌─────────────────────────┐
│  INTERNSHIP_PROGRESS    │
├─────────────────────────┤
│ PK  progress_id         │
│ FK  student_id          │
│ FK  internship_id       │
│     report_date         │
│     work_done           │
│     learning            │
│     challenges          │
│     status              │
└─────────────────────────┘
```

**Purpose:** Track student's progress during internship with detailed reports

**Relationships:**
- Submitted by ONE Student (N:1)
- For ONE Internship (N:1)
- Multiple reports per internship allowed

### 8. EVALUATION Entity
```
┌─────────────────────────┐
│      EVALUATION         │
├─────────────────────────┤
│ PK  evaluation_id       │
│ FK  student_id          │
│ FK  internship_id       │
│     evaluator_type      │
│     evaluator_name      │
│     rating              │
│     feedback            │
│     evaluated_date      │
└─────────────────────────┘
```

**Purpose:** Store performance evaluations

**Evaluator Types:**
- `Company`: Evaluation by company supervisor
- `Coordinator`: Evaluation by academic coordinator

**Relationships:**
- Evaluates ONE Student (N:1)
- For ONE Internship (N:1)

### 9. OFFER_LETTER Entity
```
┌─────────────────────────┐
│      OFFER_LETTER       │
├─────────────────────────┤
│ PK  offer_id            │
│ FK  student_id          │
│ FK  internship_id       │
│     offer_date          │
│     letter_path         │
│     status              │
└─────────────────────────┘
```

**Purpose:** Manage official offer letters

**Generated from:** APPLICATION (when status = 'Accepted')

**Relationships:**
- Issued to ONE Student (N:1)
- For ONE Internship (N:1)

### 10. CERTIFICATE Entity
```
┌─────────────────────────┐
│      CERTIFICATE        │
├─────────────────────────┤
│ PK  certificate_id      │
│ FK  student_id          │
│ FK  internship_id       │
│     certificate_date    │
│     certificate_path    │
└─────────────────────────┘
```

**Purpose:** Store completion certificates

**Generated from:** APPLICATION (when status = 'Completed')

**Relationships:**
- Issued to ONE Student (N:1)
- For ONE Internship (N:1)

## Complete Relationship Diagram

```
                    ┌──────────┐
                    │  ADMIN   │
                    └──────────┘
                         │
                    (manages all)
                         │
    ┌────────────────────┼────────────────────┐
    │                    │                    │
    ▼                    ▼                    ▼
┌─────────┐      ┌─────────────┐      ┌──────────┐
│ STUDENT │◄─────┤ COORDINATOR │      │ COMPANY  │
└────┬────┘ N:1  └─────┬───────┘      └────┬─────┘
     │                 │                    │
     │ supervised      │ supervises         │ posts
     │ by              │                    │
     │           ┌─────▼─────┐              │ 1:N
     │           │ SUPERVISOR │              │
     │           │ ALLOCATION │              │
     │           └───────────┘              │
     │                                      │
     │ 1:N                                  │
     │                                      │
     ▼                                      ▼
┌────────────┐    M:N          ┌─────────────┐
│APPLICATION │◄───applies to──►│ INTERNSHIP  │
└─────┬──────┘                 └──────┬──────┘
      │                               │
      │ generates (when accepted)     │
      │                               │
      ▼                               │
┌────────────┐                        │
│OFFER_LETTER│                        │
└────────────┘                        │
                                      │
      ┌───────────────────────────────┤
      │                               │
      ▼                               ▼
┌────────────┐              ┌──────────────────┐
│CERTIFICATE │              │INTERNSHIP_PROGRESS│
└────────────┘              └──────────────────┘
                                      │
      generated when                  │
      completed                       ▼
                            ┌──────────────┐
                            │ EVALUATION   │
                            └──────────────┘
```

## Key Workflows

### Student Application Workflow
```
1. STUDENT registers → Creates profile
2. STUDENT browses → INTERNSHIP listings
3. STUDENT applies → Creates APPLICATION
4. COMPANY reviews → Updates APPLICATION status
5. If Accepted → OFFER_LETTER generated
6. Student starts → INTERNSHIP_PROGRESS tracked
7. COORDINATOR/COMPANY → Creates EVALUATION
8. Completion → CERTIFICATE issued
```

### Supervision Workflow
```
1. ADMIN assigns → COORDINATOR to STUDENT
2. Creates → SUPERVISOR_ALLOCATION record
3. COORDINATOR monitors → INTERNSHIP_PROGRESS
4. COORDINATOR conducts → EVALUATION
5. COORDINATOR approves → CERTIFICATE
```

### Company Workflow
```
1. COMPANY registers → Creates profile
2. COMPANY posts → INTERNSHIP opportunity
3. Receives → APPLICATIONS from students
4. Reviews and updates → APPLICATION status
5. Issues → OFFER_LETTER to accepted students
6. Monitors → INTERNSHIP_PROGRESS
7. Conducts → EVALUATION
8. Signs off on → CERTIFICATE
```

## Cardinality Summary

| Relationship | Cardinality | Description |
|--------------|-------------|-------------|
| Student → Coordinator | N:1 | Many students per coordinator |
| Student → Application | 1:N | One student, many applications |
| Internship → Application | 1:N | One internship, many applications |
| Company → Internship | 1:N | One company, many internships |
| Application → Offer Letter | 1:1 | One application, one offer |
| Application → Certificate | 1:1 | One completed application, one certificate |
| Student → Progress Report | 1:N | One student, many progress reports |
| Internship → Progress Report | 1:N | One internship, many progress reports |
| Student → Evaluation | 1:N | One student, many evaluations |
| Coordinator → Supervisor Allocation | 1:N | One coordinator, many allocations |

## Database Design Principles Applied

### 1. Normalization
- All entities are in 3NF (Third Normal Form)
- No redundant data
- Atomic values in all columns

### 2. Referential Integrity
- All foreign keys properly defined
- Cascade rules for deletions
- Orphan records prevented

### 3. Data Integrity
- Primary keys on all tables
- Unique constraints on email fields
- NOT NULL constraints on critical fields
- Default values for status fields

### 4. Scalability
- Indexed foreign keys
- Separate transaction tables
- Efficient join strategies

### 5. Auditability
- Timestamp fields (created_at, updated_at)
- Status tracking
- Historical records maintained

## Status Values Reference

### Application Status
- `Pending`: Under review
- `Accepted`: Offer extended
- `Rejected`: Not selected
- `Completed`: Internship finished

### Internship Status
- `Open`: Accepting applications
- `Closed`: No longer accepting
- `Archived`: Historical record

### Student Status
- `Active`: Currently enrolled
- `Inactive`: Temporarily inactive
- `Alumni`: Graduated

### Offer Letter Status
- `Sent`: Offer sent to student
- `Accepted`: Student accepted
- `Declined`: Student declined
- `Expired`: Offer expired

## Queries You Can Perform

### Find all applications for a student
```sql
SELECT a.*, i.title, c.company_name, a.status
FROM application a
JOIN internship i ON a.internship_id = i.id
JOIN company c ON i.company_id = c.id
WHERE a.student_id = ?
```

### Find coordinator's supervised students
```sql
SELECT s.* FROM student s
WHERE s.coordinator_id = ?
```

### Get internship with application count
```sql
SELECT i.*, COUNT(a.id) as application_count
FROM internship i
LEFT JOIN application a ON i.id = a.internship_id
GROUP BY i.id
```

### Find students needing evaluation
```sql
SELECT s.*, i.title
FROM student s
JOIN application a ON s.id = a.student_id
JOIN internship i ON a.internship_id = i.id
WHERE a.status = 'Accepted'
AND NOT EXISTS (
    SELECT 1 FROM evaluation e
    WHERE e.student_id = s.id
    AND e.internship_id = i.id
)
```

---

**Schema Version:** 2.0  
**Last Updated:** 2026-06-13  
**Compliant with:** Original ER Diagram
