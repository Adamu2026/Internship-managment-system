"""
Database Migration Script
This script updates the existing database to include all new tables and fields
from the updated ER diagram.
"""

from app import app, db
from models import (
    Student, Admin, Company, Coordinator, Internship, Application,
    SupervisorAllocation, InternshipProgress, Evaluation, OfferLetter,
    Certificate, WeeklyReport
)
from sqlalchemy import text, inspect

def column_exists(table_name, column_name):
    """Check if a column exists in a table"""
    with db.engine.connect() as conn:
        result = conn.execute(text(f"PRAGMA table_info({table_name})"))
        columns = [row[1] for row in result]
        return column_name in columns

def table_exists(table_name):
    """Check if a table exists"""
    inspector = inspect(db.engine)
    return table_name in inspector.get_table_names()

def migrate_database():
    """Perform database migration"""
    print("=" * 60)
    print("Database Migration - Updating Schema")
    print("=" * 60)
    print()
    
    with app.app_context():
        # Create all new tables
        print("Creating new tables...")
        db.create_all()
        print("✓ All tables created/verified")
        print()
        
        # Add new columns to Student table
        print("Updating Student table...")
        student_columns = {
            'coordinator_id': 'INTEGER',
            'job_number': 'VARCHAR(50)',
            'student_name': 'VARCHAR(100)',
            'semester': 'INTEGER',
            'cgpa': 'DECIMAL(3,2)',
            'join_date': 'DATE',
            'status': 'VARCHAR(50) DEFAULT "Active"'
        }
        
        with db.engine.connect() as conn:
            for col_name, col_type in student_columns.items():
                if not column_exists('student', col_name):
                    try:
                        conn.execute(text(f"ALTER TABLE student ADD COLUMN {col_name} {col_type}"))
                        conn.commit()
                        print(f"  ✓ Added column: {col_name}")
                    except Exception as e:
                        print(f"  ⚠ Could not add {col_name}: {e}")
                else:
                    print(f"  → Column already exists: {col_name}")
        print()
        
        # Add new columns to Company table
        print("Updating Company table...")
        company_columns = {
            'company_name': 'VARCHAR(100)',
            'industry': 'VARCHAR(100)',
            'contact_person': 'VARCHAR(100)',
            'phone': 'VARCHAR(50)',
            'address': 'VARCHAR(200)',
            'website': 'VARCHAR(200)'
        }
        
        with db.engine.connect() as conn:
            for col_name, col_type in company_columns.items():
                if not column_exists('company', col_name):
                    try:
                        conn.execute(text(f"ALTER TABLE company ADD COLUMN {col_name} {col_type}"))
                        conn.commit()
                        print(f"  ✓ Added column: {col_name}")
                    except Exception as e:
                        print(f"  ⚠ Could not add {col_name}: {e}")
                else:
                    print(f"  → Column already exists: {col_name}")
        print()
        
        # Add new columns to Coordinator table
        print("Updating Coordinator table...")
        coordinator_columns = {
            'name': 'VARCHAR(100)'
        }
        
        with db.engine.connect() as conn:
            for col_name, col_type in coordinator_columns.items():
                if not column_exists('coordinator', col_name):
                    try:
                        conn.execute(text(f"ALTER TABLE coordinator ADD COLUMN {col_name} {col_type}"))
                        conn.commit()
                        print(f"  ✓ Added column: {col_name}")
                    except Exception as e:
                        print(f"  ⚠ Could not add {col_name}: {e}")
                else:
                    print(f"  → Column already exists: {col_name}")
        print()
        
        # Add new columns to Internship table
        print("Updating Internship table...")
        internship_columns = {
            'title': 'VARCHAR(100)',
            'domain': 'VARCHAR(100)',
            'stipend': 'DECIMAL(10,2)',
            'openings': 'INTEGER DEFAULT 1',
            'posted_date': 'DATE',
            'status': 'VARCHAR(50) DEFAULT "Open"'
        }
        
        with db.engine.connect() as conn:
            for col_name, col_type in internship_columns.items():
                if not column_exists('internship', col_name):
                    try:
                        conn.execute(text(f"ALTER TABLE internship ADD COLUMN {col_name} {col_type}"))
                        conn.commit()
                        print(f"  ✓ Added column: {col_name}")
                    except Exception as e:
                        print(f"  ⚠ Could not add {col_name}: {e}")
                else:
                    print(f"  → Column already exists: {col_name}")
        print()
        
        # Add new columns to Application table
        print("Updating Application table...")
        application_columns = {
            'application_date': 'DATE',
            'resume_path': 'VARCHAR(200)',
            'cover_letter': 'TEXT'
        }
        
        with db.engine.connect() as conn:
            for col_name, col_type in application_columns.items():
                if not column_exists('application', col_name):
                    try:
                        conn.execute(text(f"ALTER TABLE application ADD COLUMN {col_name} {col_type}"))
                        conn.commit()
                        print(f"  ✓ Added column: {col_name}")
                    except Exception as e:
                        print(f"  ⚠ Could not add {col_name}: {e}")
                else:
                    print(f"  → Column already exists: {col_name}")
        print()
        
        # Verify new tables
        print("Verifying new tables...")
        new_tables = [
            'supervisor_allocation',
            'internship_progress',
            'evaluation',
            'offer_letter',
            'certificate'
        ]
        
        for table_name in new_tables:
            if table_exists(table_name):
                print(f"  ✓ Table exists: {table_name}")
            else:
                print(f"  ✗ Table missing: {table_name}")
        print()
        
        # Update existing data for compatibility
        print("Updating existing data...")
        with db.engine.connect() as conn:
            # Copy fullname to student_name if student_name is NULL
            conn.execute(text(
                "UPDATE student SET student_name = fullname WHERE student_name IS NULL"
            ))
            
            # Copy name to company_name if company_name is NULL
            conn.execute(text(
                "UPDATE company SET company_name = name WHERE company_name IS NULL"
            ))
            
            # Copy fullname to name in coordinator if name is NULL
            conn.execute(text(
                "UPDATE coordinator SET name = fullname WHERE name IS NULL"
            ))
            
            # Copy position to title if title is NULL
            conn.execute(text(
                "UPDATE internship SET title = position WHERE title IS NULL"
            ))
            
            # Copy applied_at date to application_date
            conn.execute(text(
                "UPDATE application SET application_date = DATE(applied_at) WHERE application_date IS NULL"
            ))
            
            conn.commit()
        print("  ✓ Data compatibility updated")
        print()
        
        print("=" * 60)
        print("Migration Complete!")
        print("=" * 60)
        print()
        print("Summary:")
        print("  • All new tables created")
        print("  • All new columns added to existing tables")
        print("  • Data compatibility ensured")
        print("  • Database is ready to use with updated schema")
        print()
        print("New Tables Added:")
        print("  1. SupervisorAllocation - Links coordinators to students")
        print("  2. InternshipProgress - Tracks student progress")
        print("  3. Evaluation - Student performance evaluations")
        print("  4. OfferLetter - Offer letter management")
        print("  5. Certificate - Completion certificates")
        print()

if __name__ == '__main__':
    migrate_database()
