# Database Migration Guide

## Overview

This guide explains how to migrate your existing database to the new schema that includes all actors and entities from the updated ER diagram.

## What's New in Version 2.0?

### New Tables
1. **SupervisorAllocation** - Tracks coordinator assignments to students
2. **InternshipProgress** - Comprehensive progress tracking with work done, learning, and challenges
3. **Evaluation** - Performance evaluations by companies and coordinators
4. **OfferLetter** - Official offer letter management
5. **Certificate** - Completion certificate generation and tracking

### Updated Tables

#### Student Table
- `coordinator_id` - Link to assigned coordinator
- `job_number` - Student ID/registration number
- `student_name` - Standardized name field
- `semester` - Current semester
- `cgpa` - Cumulative GPA (decimal format)
- `join_date` - Enrollment date
- `status` - Student status (Active/Inactive)

#### Company Table
- `company_name` - Standardized company name
- `industry` - Industry sector
- `contact_person` - Primary contact name
- `phone` - Company phone number
- `address` - Physical address
- `website` - Company website URL

#### Coordinator Table
- `name` - Standardized name field

#### Internship Table
- `title` - Standardized position title
- `domain` - Field/domain of work
- `stipend` - Monthly stipend (decimal)
- `openings` - Number of available positions
- `posted_date` - Date posted
- `status` - Internship status (Open/Closed)

#### Application Table
- `application_date` - Date of application
- `resume_path` - Path to resume file
- `cover_letter` - Cover letter text

## Migration Steps

### Step 1: Backup Your Database

**CRITICAL**: Always backup before migration!

```bash
# Windows Command Prompt
cd backend
copy database\app.db database\app.db.backup
copy instance\database.db instance\database.db.backup
copy instance\internship.db instance\internship.db.backup
```

### Step 2: Check Python Environment

Ensure your virtual environment is set up and activated:

```bash
# Windows
venv\Scripts\activate

# Verify installation
python --version
pip list
```

### Step 3: Run Migration Script

```bash
python migrate_database.py
```

Expected output:
```
============================================================
Database Migration - Updating Schema
============================================================

Creating new tables...
✓ All tables created/verified

Updating Student table...
  ✓ Added column: coordinator_id
  ✓ Added column: job_number
  ✓ Added column: student_name
  ✓ Added column: semester
  ✓ Added column: cgpa
  ✓ Added column: join_date
  ✓ Added column: status

Updating Company table...
  ✓ Added column: company_name
  ✓ Added column: industry
  ✓ Added column: contact_person
  ✓ Added column: phone
  ✓ Added column: address
  ✓ Added column: website

Updating Coordinator table...
  ✓ Added column: name

Updating Internship table...
  ✓ Added column: title
  ✓ Added column: domain
  ✓ Added column: stipend
  ✓ Added column: openings
  ✓ Added column: posted_date
  ✓ Added column: status

Updating Application table...
  ✓ Added column: application_date
  ✓ Added column: resume_path
  ✓ Added column: cover_letter

Verifying new tables...
  ✓ Table exists: supervisor_allocation
  ✓ Table exists: internship_progress
  ✓ Table exists: evaluation
  ✓ Table exists: offer_letter
  ✓ Table exists: certificate

Updating existing data...
  ✓ Data compatibility updated

============================================================
Migration Complete!
============================================================
```

### Step 4: Verify Migration

1. **Check for errors** in the output
2. **Test the application**:
   ```bash
   python run.py
   ```
3. **Access the application**: http://localhost:5000
4. **Test key features**:
   - Login as admin
   - View students list
   - Check internships
   - Test application creation

### Step 5: Clean Up (Optional)

Once verified, you can optionally remove backup files:

```bash
# Keep backups for at least a week!
# Only delete if everything works perfectly
del database\app.db.backup
```

## Rollback Procedure

If something goes wrong, you can restore from backup:

```bash
# Stop the application first (Ctrl+C)

# Restore backup
copy database\app.db.backup database\app.db

# Restart application
python run.py
```

## Common Issues

### Issue: "Table already exists"
**Solution**: This is normal. The migration script safely handles existing tables.

### Issue: "Column already exists"
**Solution**: This is normal for repeated migrations. Existing columns are skipped.

### Issue: "Database is locked"
**Solution**: 
1. Stop all running instances of the application
2. Close any database viewers (DB Browser for SQLite, etc.)
3. Re-run the migration

### Issue: "No module named 'app'"
**Solution**: Make sure you're in the `backend` directory:
```bash
cd backend
python migrate_database.py
```

### Issue: Foreign key constraint failed
**Solution**: This indicates data integrity issues. Check:
1. Orphaned records (applications without students/internships)
2. Run cleanup script or manually fix data relationships

## Data Integrity Checks

After migration, verify:

```sql
-- Check for orphaned applications
SELECT * FROM application 
WHERE student_id NOT IN (SELECT id FROM student);

-- Check for orphaned internships
SELECT * FROM internship 
WHERE company_id NOT IN (SELECT id FROM company);

-- Verify student-coordinator relationships
SELECT s.id, s.student_name, c.name 
FROM student s 
LEFT JOIN coordinator c ON s.coordinator_id = c.id;
```

## New Features Available After Migration

### 1. Supervisor Allocation
Coordinators can now be assigned to supervise specific students.

### 2. Progress Tracking
Students can submit detailed progress reports including:
- Work completed
- Learning outcomes
- Challenges faced

### 3. Evaluations
Both companies and coordinators can evaluate student performance with:
- Numeric ratings
- Detailed feedback
- Evaluation history

### 4. Offer Letters
System can generate and track offer letters for accepted applications.

### 5. Certificates
Automatic certificate generation upon internship completion.

## Database Schema Version

After migration:
- **Schema Version**: 2.0
- **Models Version**: Updated to match ER diagram
- **Backward Compatible**: Yes, with legacy fields maintained

## Performance Considerations

After migration, consider:

1. **Adding indexes** for faster queries:
   ```sql
   CREATE INDEX idx_student_coordinator ON student(coordinator_id);
   CREATE INDEX idx_application_status ON application(status);
   CREATE INDEX idx_internship_company ON internship(company_id);
   ```

2. **Optimizing queries** in your code to use new fields

3. **Regular database maintenance**:
   ```sql
   VACUUM;
   ANALYZE;
   ```

## Support

If you encounter issues:

1. Check the console output for specific error messages
2. Review the [DATABASE_SCHEMA.md](DATABASE_SCHEMA.md) documentation
3. Verify all dependencies are installed: `pip install -r requirements.txt`
4. Ensure Flask-Mail is installed (added in updated requirements.txt)

## Next Steps

After successful migration:

1. ✅ Update your application code to use new features
2. ✅ Test all user workflows (student, company, coordinator, admin)
3. ✅ Update any custom queries or reports
4. ✅ Train users on new features
5. ✅ Monitor application logs for any issues

---

**Migration Script**: `migrate_database.py`  
**Schema Documentation**: `DATABASE_SCHEMA.md`  
**Last Updated**: 2026-06-13
