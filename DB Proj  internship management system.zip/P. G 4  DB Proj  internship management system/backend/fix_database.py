"""
Simple database fix script
Adds missing columns to existing database
"""

import sqlite3
import os

def fix_database():
    """Add missing columns to database"""
    
    # Path to database
    db_path = os.path.join('database', 'app.db')
    
    if not os.path.exists(db_path):
        print(f"Database not found at: {db_path}")
        print("Creating new database - run app.py after this")
        return
    
    print("=" * 60)
    print("Database Fix Script")
    print("=" * 60)
    print()
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Get existing columns in coordinator table
    cursor.execute("PRAGMA table_info(coordinator)")
    coordinator_columns = [row[1] for row in cursor.fetchall()]
    
    print("Current coordinator columns:", coordinator_columns)
    print()
    
    # Add missing columns
    print("Adding missing columns...")
    print()
    
    # Add 'name' column to coordinator if it doesn't exist
    if 'name' not in coordinator_columns:
        try:
            cursor.execute("ALTER TABLE coordinator ADD COLUMN name VARCHAR(100)")
            print("✓ Added column: coordinator.name")
        except sqlite3.OperationalError as e:
            print(f"✗ Could not add coordinator.name: {e}")
    else:
        print("→ coordinator.name already exists")
    
    # Copy fullname to name where name is NULL
    try:
        cursor.execute("UPDATE coordinator SET name = fullname WHERE name IS NULL")
        rows_updated = cursor.rowcount
        if rows_updated > 0:
            print(f"✓ Copied fullname to name for {rows_updated} coordinators")
    except Exception as e:
        print(f"✗ Could not copy data: {e}")
    
    # Get existing columns in student table
    cursor.execute("PRAGMA table_info(student)")
    student_columns = [row[1] for row in cursor.fetchall()]
    
    # Add missing student columns
    student_new_columns = {
        'coordinator_id': 'INTEGER',
        'job_number': 'VARCHAR(50)',
        'student_name': 'VARCHAR(100)',
        'semester': 'INTEGER',
        'cgpa': 'DECIMAL(3,2)',
        'join_date': 'DATE',
        'status': 'VARCHAR(50) DEFAULT "Active"'
    }
    
    for col_name, col_type in student_new_columns.items():
        if col_name not in student_columns:
            try:
                cursor.execute(f"ALTER TABLE student ADD COLUMN {col_name} {col_type}")
                print(f"✓ Added column: student.{col_name}")
            except sqlite3.OperationalError as e:
                print(f"→ student.{col_name}: {e}")
    
    # Copy fullname to student_name where student_name is NULL
    try:
        cursor.execute("UPDATE student SET student_name = fullname WHERE student_name IS NULL")
        rows_updated = cursor.rowcount
        if rows_updated > 0:
            print(f"✓ Copied fullname to student_name for {rows_updated} students")
    except Exception as e:
        pass
    
    # Get existing columns in company table
    cursor.execute("PRAGMA table_info(company)")
    company_columns = [row[1] for row in cursor.fetchall()]
    
    # Add missing company columns
    company_new_columns = {
        'company_name': 'VARCHAR(100)',
        'industry': 'VARCHAR(100)',
        'contact_person': 'VARCHAR(100)',
        'phone': 'VARCHAR(50)',
        'address': 'VARCHAR(200)',
        'website': 'VARCHAR(200)'
    }
    
    for col_name, col_type in company_new_columns.items():
        if col_name not in company_columns:
            try:
                cursor.execute(f"ALTER TABLE company ADD COLUMN {col_name} {col_type}")
                print(f"✓ Added column: company.{col_name}")
            except sqlite3.OperationalError as e:
                print(f"→ company.{col_name}: {e}")
    
    # Copy name to company_name where company_name is NULL
    try:
        cursor.execute("UPDATE company SET company_name = name WHERE company_name IS NULL")
        rows_updated = cursor.rowcount
        if rows_updated > 0:
            print(f"✓ Copied name to company_name for {rows_updated} companies")
    except Exception as e:
        pass
    
    # Get existing columns in internship table
    cursor.execute("PRAGMA table_info(internship)")
    internship_columns = [row[1] for row in cursor.fetchall()]
    
    # Add missing internship columns
    internship_new_columns = {
        'title': 'VARCHAR(100)',
        'domain': 'VARCHAR(100)',
        'stipend': 'DECIMAL(10,2)',
        'openings': 'INTEGER DEFAULT 1',
        'posted_date': 'DATE',
        'status': 'VARCHAR(50) DEFAULT "Open"'
    }
    
    for col_name, col_type in internship_new_columns.items():
        if col_name not in internship_columns:
            try:
                cursor.execute(f"ALTER TABLE internship ADD COLUMN {col_name} {col_type}")
                print(f"✓ Added column: internship.{col_name}")
            except sqlite3.OperationalError as e:
                print(f"→ internship.{col_name}: {e}")
    
    # Copy position to title where title is NULL
    try:
        cursor.execute("UPDATE internship SET title = position WHERE title IS NULL")
        rows_updated = cursor.rowcount
        if rows_updated > 0:
            print(f"✓ Copied position to title for {rows_updated} internships")
    except Exception as e:
        pass
    
    # Get existing columns in application table
    cursor.execute("PRAGMA table_info(application)")
    application_columns = [row[1] for row in cursor.fetchall()]
    
    # Add missing application columns
    application_new_columns = {
        'application_date': 'DATE',
        'resume_path': 'VARCHAR(200)',
        'cover_letter': 'TEXT'
    }
    
    for col_name, col_type in application_new_columns.items():
        if col_name not in application_columns:
            try:
                cursor.execute(f"ALTER TABLE application ADD COLUMN {col_name} {col_type}")
                print(f"✓ Added column: application.{col_name}")
            except sqlite3.OperationalError as e:
                print(f"→ application.{col_name}: {e}")
    
    # Commit all changes
    conn.commit()
    conn.close()
    
    print()
    print("=" * 60)
    print("Database fix completed!")
    print("=" * 60)
    print()
    print("You can now run: python app.py")
    print()

if __name__ == '__main__':
    fix_database()
