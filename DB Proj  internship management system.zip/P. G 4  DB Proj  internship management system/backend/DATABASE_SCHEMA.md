# Database Schema Documentation

## Overview

This document describes the complete database schema for the Student Internship Management System, based on the ER diagram with all actors and relationships.

## Entity Relationship Diagram

The system includes the following main entities:
- **STUDENT**: Students seeking internships
- **COMPANY**: Companies offering internships
- **COORDINATOR**: Academic supervisors monitoring students
- **ADMIN**: System administrators
- **INTERNSHIP**: Internship opportunities
- **APPLICATION**: Student applications to internships
- **SUPERVISOR ALLOCATION**: Assignment of coordinators to students
- **INTERNSHIP PROGRESS**: Weekly/periodic progress reports
- **EVALUATION**: Performance evaluations
- **OFFER LETTER**: Official offer letters
- **CERTIFICATE**: Completion certificates

## Tables and Relationships

### 1. STUDENT Table
Stores student information and profiles.

| Column | Type | Description | Constraints |
|--------|------|-------------|-------------|
| id | INTEGER | Primary Key | PK, AUTO_INCREMENT |
| coordinator_id | INTEGER | Assigned coordinator | FK → coordinator.id |
| job_number | VARCHAR(50) | Student ID/Job number | |
| student_name | VARCHAR(100) | Student full name | NOT NULL |
| fullname | VARCHAR(100) | Alias for student_name | |
| email | VARCHAR(100) | Email address | UNIQUE, NOT NULL |
| phone | VARCHAR(50) | Phone number | |
| semester | INTEGER | Current semester | |
| cgpa | DECIMAL(3,2) | Cumulative GPA | |
| gpa | VARCHAR(20) | GPA string (legacy) | |
| join_date | DATE | Enrollment date | |
| status | VARCHAR(50) | Student status | DEFAULT 'Active' |
| department | VARCHAR(100) | Academic department | |
| password | VARCHAR(100) | Login password | NOT NULL |
| skills | TEXT | Technical skills | |
| cv_filename | VARCHAR(200) | Uploaded CV file | |
| profile_photo_filename | VARCHAR(200) | Profile photo | |
| certificate_filename | VARCHAR(200) | Certificates | |
| role | VARCHAR(20) | User role | DEFAULT 'student' |

**Relationships:**
- Many-to-One with COORDINATOR (via coordinator_id)
- One-to-Many with APPLICATION
- One-to-Many with SUPERVISOR_ALLOCATION
- One-to-Many with INTERNSHIP_PROGRESS
- One-to-Many with EVALUATION
- One-to-Many with OFFER_LETTER
- One-to-Many with CERTIFICATE

---

### 2. COMPANY Table
Stores company information for internship providers.

| Column | Type | Description | Constraints |
|--------|------|-------------|-------------|
| id | INTEGER | Primary Key | PK, AUTO_INCREMENT |
| company_name | VARCHAR(100) | Company name | NOT NULL |
| name | VARCHAR(100) | Alias for company_name | |
| industry | VARCHAR(100) | Industry sector | |
| contact_person | VARCHAR(100) | Contact person name | |
| email | VARCHAR(100) | Company email | UNIQUE, NOT NULL |
| phone | VARCHAR(50) | Phone number | |
| address | VARCHAR(200) | Physical address | |
| website | VARCHAR(200) | Company website | |
| location | VARCHAR(100) | City/location | |
| password | VARCHAR(100) | Login password | NOT NULL |
| description | TEXT | Company description | |
| logo_filename | VARCHAR(200) | Company logo | |

**Relationships:**
- One-to-Many with INTERNSHIP

---

### 3. COORDINATOR Table
Stores academic coordinator/supervisor information.

| Column | Type | Description | Constraints |
|--------|------|-------------|-------------|
| id | INTEGER | Primary Key | PK, AUTO_INCREMENT |
| name | VARCHAR(100) | Coordinator name | NOT NULL |
| fullname | VARCHAR(100) | Alias for name | |
| email | VARCHAR(100) | Email address | UNIQUE, NOT NULL |
| phone | VARCHAR(50) | Phone number | |
| department | VARCHAR(100) | Department | |
| password | VARCHAR(100) | Login password | NOT NULL |

**Relationships:**
- One-to-Many with STUDENT (supervision)
- One-to-Many with SUPERVISOR_ALLOCATION

---

### 4. ADMIN Table
System administrators with full access.

| Column | Type | Description | Constraints |
|--------|------|-------------|-------------|
| id | INTEGER | Primary Key | PK, AUTO_INCREMENT |
| username | VARCHAR(100) | Admin username | NOT NULL |
| password | VARCHAR(100) | Login password | NOT NULL |

---

### 5. INTERNSHIP Table
Internship opportunities posted by companies.

| Column | Type | Description | Constraints |
|--------|------|-------------|-------------|
| id | INTEGER | Primary Key | PK, AUTO_INCREMENT |
| company_id | INTEGER | Company offering | FK → company.id, NOT NULL |
| title | VARCHAR(100) | Position title | NOT NULL |
| position | VARCHAR(100) | Alias for title | |
| description | TEXT | Job description | |
| domain | VARCHAR(100) | Field/domain | |
| location | VARCHAR(100) | Work location | |
| start_date | DATE | Internship start date | |
| end_date | DATE | Internship end date | |
| stipend | DECIMAL(10,2) | Monthly stipend | |
| salary | VARCHAR(100) | Salary string (legacy) | |
| openings | INTEGER | Number of positions | DEFAULT 1 |
| posted_date | DATE | Date posted | |
| status | VARCHAR(50) | Internship status | DEFAULT 'Open' |
| company | VARCHAR(100) | Company name (legacy) | |

**Relationships:**
- Many-to-One with COMPANY (via company_id)
- One-to-Many with APPLICATION
- Generates OFFER_LETTER (via APPLICATION)
- One-to-Many with INTERNSHIP_PROGRESS
- One-to-Many with EVALUATION
- Generates CERTIFICATE (via completion)

---

### 6. APPLICATION Table
Student applications to internships.

| Column | Type | Description | Constraints |
|--------|------|-------------|-------------|
| id | INTEGER | Primary Key | PK, AUTO_INCREMENT |
| student_id | INTEGER | Applicant | FK → student.id, NOT NULL |
| internship_id | INTEGER | Applied internship | FK → internship.id, NOT NULL |
| application_date | DATE | Date of application | |
| applied_at | DATETIME | Timestamp | DEFAULT NOW |
| status | VARCHAR(50) | Application status | DEFAULT 'Pending' |
| resume_path | VARCHAR(200) | Resume file path | |
| cover_letter | TEXT | Cover letter content | |

**Status Values:**
- `Pending`: Under review
- `Accepted`: Offer extended
- `Rejected`: Not selected
- `Completed`: Internship finished

**Relationships:**
- Many-to-One with STUDENT
- Many-to-One with INTERNSHIP
- Generates OFFER_LETTER (when Accepted)

---

### 7. SUPERVISOR_ALLOCATION Table
Assignment of coordinators to supervise students.

| Column | Type | Description | Constraints |
|--------|------|-------------|-------------|
| id | INTEGER | Primary Key | PK, AUTO_INCREMENT |
| student_id | INTEGER | Supervised student | FK → student.id, NOT NULL |
| coordinator_id | INTEGER | Supervising coordinator | FK → coordinator.id, NOT NULL |
| assigned_date | DATE | Assignment date | DEFAULT NOW |

**Relationships:**
- Many-to-One with STUDENT
- Many-to-One with COORDINATOR

---

### 8. INTERNSHIP_PROGRESS Table
Tracks student progress during internship period.

| Column | Type | Description | Constraints |
|--------|------|-------------|-------------|
| id | INTEGER | Primary Key | PK, AUTO_INCREMENT |
| student_id | INTEGER | Student | FK → student.id, NOT NULL |
| internship_id | INTEGER | Internship | FK → internship.id, NOT NULL |
| report_date | DATE | Report date | DEFAULT NOW |
| work_done | TEXT | Work completed | NOT NULL |
| learning | TEXT | Learning outcomes | |
| challenges | TEXT | Challenges faced | |
| status | VARCHAR(50) | Progress status | DEFAULT 'In Progress' |

**Relationships:**
- Many-to-One with STUDENT
- Many-to-One with INTERNSHIP

---

### 9. EVALUATION Table
Performance evaluations by company or coordinator.

| Column | Type | Description | Constraints |
|--------|------|-------------|-------------|
| id | INTEGER | Primary Key | PK, AUTO_INCREMENT |
| student_id | INTEGER | Evaluated student | FK → student.id, NOT NULL |
| internship_id | INTEGER | Related internship | FK → internship.id, NOT NULL |
| evaluator_type | VARCHAR(50) | Evaluator role | NOT NULL |
| evaluator_name | VARCHAR(100) | Evaluator name | |
| rating | DECIMAL(3,2) | Performance rating | |
| feedback | TEXT | Evaluation feedback | |
| evaluated_date | DATE | Evaluation date | DEFAULT NOW |

**Evaluator Types:**
- `Company`: Evaluation by company supervisor
- `Coordinator`: Evaluation by academic coordinator

**Relationships:**
- Many-to-One with STUDENT
- Many-to-One with INTERNSHIP

---

### 10. OFFER_LETTER Table
Official offer letters for accepted applications.

| Column | Type | Description | Constraints |
|--------|------|-------------|-------------|
| id | INTEGER | Primary Key | PK, AUTO_INCREMENT |
| student_id | INTEGER | Recipient student | FK → student.id, NOT NULL |
| internship_id | INTEGER | Offered internship | FK → internship.id, NOT NULL |
| offer_date | DATE | Date issued | DEFAULT NOW |
| letter_path | VARCHAR(200) | PDF file path | NOT NULL |
| status | VARCHAR(50) | Offer status | DEFAULT 'Sent' |

**Generated from:** APPLICATION (when status = 'Accepted')

**Relationships:**
- Many-to-One with STUDENT
- Many-to-One with INTERNSHIP

---

### 11. CERTIFICATE Table
Completion certificates issued to students.

| Column | Type | Description | Constraints |
|--------|------|-------------|-------------|
| id | INTEGER | Primary Key | PK, AUTO_INCREMENT |
| student_id | INTEGER | Certificate recipient | FK → student.id, NOT NULL |
| internship_id | INTEGER | Completed internship | FK → internship.id, NOT NULL |
| certificate_date | DATE | Issue date | DEFAULT NOW |
| certificate_path | VARCHAR(200) | PDF file path | NOT NULL |

**Generated from:** APPLICATION (when status = 'Completed')

**Relationships:**
- Many-to-One with STUDENT
- Many-to-One with INTERNSHIP

---

### 12. WEEKLY_REPORT Table (Legacy)
Weekly progress reports - superseded by INTERNSHIP_PROGRESS.

| Column | Type | Description | Constraints |
|--------|------|-------------|-------------|
| id | INTEGER | Primary Key | PK, AUTO_INCREMENT |
| student_id | INTEGER | Student | FK → student.id |
| internship_id | INTEGER | Internship | FK → internship.id |
| application_id | INTEGER | Application | FK → application.id |
| week_number | INTEGER | Week number | |
| progress | TEXT | Weekly progress | |
| created_at | DATETIME | Creation timestamp | DEFAULT NOW |

**Note:** This table is maintained for backward compatibility. New implementations should use INTERNSHIP_PROGRESS.

---

## Key Relationships and Workflows

### Application Flow
```
STUDENT → applies to → INTERNSHIP
                ↓
           APPLICATION (Pending)
                ↓
        COMPANY reviews
                ↓
     [Accepted] → OFFER_LETTER generated
                ↓
   Student starts internship
                ↓
     INTERNSHIP_PROGRESS tracked
                ↓
        EVALUATION conducted
                ↓
   [Completed] → CERTIFICATE issued
```

### Supervision Flow
```
COORDINATOR assigned to → STUDENT
                ↓
       SUPERVISOR_ALLOCATION
                ↓
   Monitors INTERNSHIP_PROGRESS
                ↓
   Conducts EVALUATION
```

### Complete Entity Relationships
```
STUDENT (1) ─── supervises ─── (N) COORDINATOR
   │                                    │
   │                                    │
   │ applies to (N)                     │
   │                                    │
   ↓                                    ↓
APPLICATION                    SUPERVISOR_ALLOCATION
   │
   │ for (1)
   ↓
INTERNSHIP ─── posted by ─── (1) COMPANY
   │
   │ generates (1)
   │
   ├─→ OFFER_LETTER
   ├─→ INTERNSHIP_PROGRESS
   ├─→ EVALUATION
   └─→ CERTIFICATE
```

## Indexes (Recommended)

For optimal performance, consider adding these indexes:

```sql
-- Student indexes
CREATE INDEX idx_student_email ON student(email);
CREATE INDEX idx_student_coordinator ON student(coordinator_id);

-- Application indexes
CREATE INDEX idx_application_student ON application(student_id);
CREATE INDEX idx_application_internship ON application(internship_id);
CREATE INDEX idx_application_status ON application(status);

-- Internship indexes
CREATE INDEX idx_internship_company ON internship(company_id);
CREATE INDEX idx_internship_status ON internship(status);

-- Progress indexes
CREATE INDEX idx_progress_student ON internship_progress(student_id);
CREATE INDEX idx_progress_internship ON internship_progress(internship_id);
```

## Migration Instructions

To update an existing database to this schema:

1. **Backup your current database**
   ```bash
   copy database\app.db database\app.db.backup
   ```

2. **Run the migration script**
   ```bash
   python migrate_database.py
   ```

3. **Verify the migration**
   - Check console output for any errors
   - Verify all new tables exist
   - Test application functionality

## Data Constraints

### Business Rules
1. A student can apply to multiple internships
2. An internship can receive multiple applications
3. A coordinator can supervise multiple students
4. A student has one primary coordinator
5. Offer letters are generated only for accepted applications
6. Certificates are issued only for completed internships
7. Progress reports can be submitted multiple times per internship
8. Both company and coordinator can evaluate students

### Status Transitions
- **Application**: Pending → Accepted/Rejected → Completed
- **Internship**: Open → Closed → Archived
- **Student**: Active → Inactive → Alumni

---

**Last Updated:** 2026-06-13
**Schema Version:** 2.0
**Compatible with:** Flask 3.1.3, SQLAlchemy 2.0.49
