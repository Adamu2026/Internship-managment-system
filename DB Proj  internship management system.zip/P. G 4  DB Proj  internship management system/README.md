# Internship Management System

A comprehensive web-based platform for managing internship programs, connecting students, companies, coordinators, and administrators.

## 📋 Overview

The Internship Management System facilitates the entire internship lifecycle - from student registration and application to company management, coordinator supervision, and administrative oversight.

## ✨ Features

### For Students
- Complete profile with CV, photo, certificates, GPA, and skills
- Browse and search internships by position, company, or location
- Apply for internships and track application status
- Submit weekly progress reports
- Download completion certificates

### For Companies
- Manage company profile with logo and description
- Post and manage internship opportunities
- Review student applications
- Evaluate student performance
- Send interview invitations

### For Coordinators
- Monitor student progress and applications
- Review weekly progress reports
- Access dashboard with analytics
- Track applications across all students

### For Administrators
- Manage all users (students, companies, coordinators)
- System overview with comprehensive analytics
- Oversee all applications and status changes
- View monthly application trends and approval rates

## 🛠️ Technology Stack

**Backend:**
- Flask 3.1.3
- SQLite with SQLAlchemy ORM
- Flask-Mail for notifications
- Session-based authentication

**Frontend:**
- Jinja2 templates
- CSS styling
- JavaScript

## 📁 Project Structure

```
hope/
├── backend/
│   ├── app.py                    # Main Flask application
│   ├── models.py                 # Database models
│   ├── requirements.txt          # Python dependencies
│   ├── database/
│   │   └── app.db               # SQLite database
│   ├── static/
│   │   ├── css/
│   │   └── uploads/             # User uploaded files
│   ├── templates/               # HTML templates
│   └── venv/                    # Virtual environment
├── frontend/                    # React frontend (optional)
└── README.md                    # This file
```

## 🚀 Installation & Setup

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Setup Instructions

1. **Clone the repository**
```bash
git clone <repository-url>
cd hope/backend
```

2. **Create virtual environment**
```bash
python -m venv venv
```

3. **Activate virtual environment**
```bash
# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate
```

4. **Install dependencies**
```bash
pip install -r requirements.txt
```

5. **Run the application**
```bash
python app.py
```

6. **Access the application**
```
http://localhost:5000
```

## 🔐 Default Credentials

**Administrator:**
- Username: `admin`
- Password: `admin123`

**Coordinator:**
- Email: `coordinator@example.com`
- Password: `coord123`

**⚠️ Important:** Change these default credentials after first login.

## 📊 Database Schema

The system includes comprehensive database models with all actors and relationships:

### Core Entities
- **Student** - Profile, academic info, skills, documents
- **Company** - Company details, contact information
- **Coordinator** - Academic supervisors
- **Admin** - System administrators
- **Internship** - Job opportunities with details
- **Application** - Student applications to internships

### Transaction Entities
- **SupervisorAllocation** - Coordinator-student assignments
- **InternshipProgress** - Detailed progress tracking
- **Evaluation** - Performance evaluations
- **OfferLetter** - Generated offer letters
- **Certificate** - Completion certificates
- **WeeklyReport** - Progress reports

For detailed schema documentation, see `backend/DATABASE_SCHEMA.md`

## 📧 Email Configuration

To enable email notifications, update the email settings in `app.py`:

```python
app.config['MAIL_USERNAME'] = 'your-email@gmail.com'
app.config['MAIL_PASSWORD'] = 'your-app-password'
```

For Gmail, use an [App Password](https://support.google.com/accounts/answer/185833).

## 🔄 Database Migration

**If you get database errors** like "no such column", run the fix script first:

```bash
# Activate virtual environment
venv\Scripts\activate

# Fix database schema
python fix_database.py

# Then run the application
python app.py
```

This adds all the new columns needed by the updated models.

## 🔒 Security Notes

**⚠️ For Production Deployment:**

1. **Change secret keys** in `app.py`
2. **Use environment variables** for sensitive data
3. **Implement password hashing** (currently plain text)
4. **Use HTTPS** with SSL certificates
5. **Use production database** (PostgreSQL/MySQL)
6. **Use production WSGI server** (Gunicorn/uWSGI)

## 📝 File Upload Support

**Supported formats:**
- CV/Resume: PDF, DOC, DOCX
- Photos: JPG, JPEG, PNG, GIF
- Certificates: PDF, DOC, DOCX, JPG, JPEG, PNG
- Company Logos: JPG, JPEG, PNG, GIF

Files are stored in `backend/static/uploads/`

## 🔧 Troubleshooting

### "ModuleNotFoundError: No module named 'flask'"
**Solution**: Activate virtual environment first
```bash
venv\Scripts\activate
pip install -r requirements.txt
```

### "Virtual environment not found"
**Solution**: Create virtual environment
```bash
python -m venv venv
```

### "Port 5000 is already in use"
**Solution**: Change port in `app.py` or stop other applications using port 5000

### Email notifications not working
**Solution**: Update email credentials in `app.py` and use Gmail App Password

### Database errors
**Solution**: Delete and recreate database (data will be lost)
```bash
del database\app.db
python app.py
```

## 🧪 Testing

1. Register as a student
2. Register as a company
3. Company posts an internship
4. Student applies
5. Company reviews and accepts/rejects
6. Student submits weekly reports
7. Admin oversees the process

## 🚀 Production Deployment

### Using Gunicorn (Linux/Mac)
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Environment Variables
```bash
export SECRET_KEY="your-secret-key"
export MAIL_USERNAME="your-email"
export MAIL_PASSWORD="your-password"
export DATABASE_URL="your-database-url"
```

### Production Checklist
- [ ] Change all default passwords
- [ ] Set secure secret key
- [ ] Configure production database
- [ ] Enable HTTPS
- [ ] Implement password hashing
- [ ] Set up logging
- [ ] Configure backup strategy
- [ ] Set up monitoring

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is available for educational and personal use.

## 👥 User Roles & Permissions

| Feature | Student | Company | Coordinator | Admin |
|---------|---------|---------|-------------|-------|
| View Internships | ✅ | ✅ | ✅ | ✅ |
| Apply for Internships | ✅ | ❌ | ❌ | ❌ |
| Post Internships | ❌ | ✅ | ❌ | ✅ |
| Review Applications | ❌ | ✅ | ✅ | ✅ |
| Submit Reports | ✅ | ❌ | ❌ | ❌ |
| View Reports | Own | For postings | All | All |
| Manage Users | ❌ | ❌ | ❌ | ✅ |
| System Analytics | ❌ | Limited | ✅ | ✅ |

## 📞 Support

For issues or questions, open an issue in the repository.

---

**Built for educational institutions and companies seeking streamlined internship management**
